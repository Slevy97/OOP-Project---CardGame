
var express = require('express');
var app = express();
var url = require('url');
var bodyParser = require('body-parser');


//app.use('/game', express.static(__dirname + '/public')); //trimit pagina html
app.use(bodyParser.urlencoded({ extended: false }));

app.post('/test', function(req, res) {
     res.send("A mers!");
});

var action = false;
var highlighted = false;
var id = 0;
var intrati = 0;
var prev_name = ""; //testing 1
var table = "";
var carte = -1;
var tura = 1;

app.post('/sendTable', function(req, res) {
	 action = true;
	 tura = req.body.name;
	 table = req.body.table;
	 res.end();
});

app.post('/getTable', function(req, res) {
	 var ceva = parseInt(req.body.name);
	 if(ceva == tura)	 
		res.send("A");
	 else
		res.send(table);
});


app.post('/getID', function(req, res) {
	id++;
	res.send(id.toString());
});

app.post('/play', function(req, res) {
	intrati++;
	res.end();
});

app.post('/checkStart', function(req, res) {
	if(intrati == 2)
		res.send("Da");
	res.send("Nu");
});

app.post('/checkMove', function(req, res) {
	if(action == true)
	{
		res.write("Da");
		action = false;
	}
	else
		res.write("Nu");
	res.end();
});

app.post('/sendHighlight', function(req, res) {
	highlighted = true;
	carte = req.body.carte;
	res.end();
});

app.post('/getHighlight', function(req, res) {
	if(highlighted == true)
	{
		res.send(carte.toString());
		highlighted = false;
	}
	else
		res.send("Nu");
});

app.post('/endTurn', function(req, res) {
	tura = 3 - parseInt(req.body.name);
	res.end();
});

app.post('/getTurn', function(req, res) {
	var player = parseInt(req.body.name);
	if(player == tura)
		res.send("Da");
	else
		res.send("Nu");
});

app.post('/restart', function(req, res) {
	id = 0;
	intrati = 0;
	prev_name = "";
	table = "";
	action = false;
	highlighted = false;
	carte = -1;
	tura = 1;
	res.end();
});



app.listen(process.env.PORT || 5000);

